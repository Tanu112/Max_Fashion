<html>
    <head>
        <style>
        body {
        background: url(cit1.jpg);
        background-size: 100%;
        background-repeat: no-repeat;
        }
        form
        {
        width: 30%;
        box-sizing: border-box;
        border: solid #DB7093;
        background-color: #FFF0F5;
        color: black;
        }
        </style>
    </head>
    <body>
        <font face="calibri" size="7">Library Access</font><br>
        <form action="11.verify.php">
            <pre>
            <font face="calibri" size="5">Library Entry</font>
            <font face="calibri" size="3">
                <br>Username<input type="text" name="name" size=20>
                <br>Password<input type="password" name="pass" size=20>       
                <br><input type=submit>         <input type=reset>
            </font>
            </pre>
        </form>
    </body>
</html>